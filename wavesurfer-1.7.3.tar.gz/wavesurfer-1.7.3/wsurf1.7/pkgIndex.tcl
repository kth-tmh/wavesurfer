# Automatically generated package index file
# date   : Wed Oct 20 15:02:16 CEST 2004
# cmdline: ./mkPkgIndex.tcl src/wsurf.tcl src/surfutil.tcl src/resizer.tcl src/vtcanvas.tcl src/notebook.tcl src/wavebar.tcl src/messagebar.tcl src/cmdline.tcl src/combobox.tcl src/pkgIndex.tcl src/htmllib.tcl src/tkcon.tcl
package ifneeded cmdline 1.1 [list source [file join $dir cmdline.tcl]]
package ifneeded surfutil 1.7 [list source [file join $dir surfutil.tcl]]
package ifneeded wsurf 1.7 [list source [file join $dir wsurf.tcl]]\n[list source [file join $dir resizer.tcl]]\n[list source [file join $dir vtcanvas.tcl]]\n[list source [file join $dir notebook.tcl]]\n[list source [file join $dir wavebar.tcl]]\n[list source [file join $dir messagebar.tcl]]\n[list source [file join $dir htmllib.tcl]]
package ifneeded tkcon 2.4 [list source [file join $dir tkcon.tcl]]
package ifneeded combobox 2.2 [list source [file join $dir combobox.tcl]]
